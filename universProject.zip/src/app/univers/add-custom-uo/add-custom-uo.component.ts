import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-custom-uo',
  templateUrl: './add-custom-uo.component.html',
  styleUrls: ['./add-custom-uo.component.css']
})
export class AddCustomUoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
