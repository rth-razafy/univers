import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-univers',
  templateUrl: './home-univers.component.html',
  styleUrls: ['./home-univers.component.css']
})
export class HomeUniversComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
