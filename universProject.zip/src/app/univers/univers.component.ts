import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-univers',
  templateUrl: './univers.component.html',
  styleUrls: ['./univers.component.css']
})
export class UniversComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
